/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */

// The instructions were kind of confusing, so apologize if I just did things my own way.
(function(){
    var actions = ["Sleeping", "Eating", "Working", "Driving", "Partying", "Exercising", "Shopping", "Cooking", "Studying"];
    var jobs = ["Actor", "Judge", "Retail", "Nurse", "Accountant", "Teacher", "Officer", "Secretary", "Janitor", "Student"];

    function Person(n, a, j) {
        this.name = n;
        this.action = actions[~~(a * actions.length)];
        this.job = jobs[~~(j * jobs.length)];
    }

    Person.prototype.update = function(i) {
        this.action = actions[~~(i * actions.length)];
    };

    window.Person = Person;
})();