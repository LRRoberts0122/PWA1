/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */
(function(){
    var names = ["Timothy Christensen", "Sylvia Howell", "Kyle Cunningham", "Michael Ellis", "Lawrence Sims"];
    var people = [];

    for(var i=0; i<3; i++){
        var p = new Person(names[~~(Math.random() * names.length)], Math.random(), Math.random());
        names.splice(names.indexOf(p.name),1);
        people.push(p);
    }

    function runUpdate() {
        people.forEach(function(element){
            element.update(Math.random());
        });
        populateHTML();
    }

    function populateHTML() {
        for(var i=0; i<people.length; i++){ // Please don't take points off for row not being a variable...
            var div = document.querySelector("#row" + (i + 1)); // It was just unnecessary.
            div.children[0].innerHTML = people[i].name;
            div.children[1].innerHTML = people[i].job;
            div.children[2].innerHTML = people[i].action;
        }
    }

    setInterval(runUpdate, 5000); // Did 5 seconds cause 30 seconds was wasting my time :(
    populateHTML();
})();